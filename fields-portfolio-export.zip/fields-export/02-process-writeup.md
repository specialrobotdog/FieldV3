# Fields — Process Write-up
*For the "See every step" dialog*

## The spec

Before writing any code, I listed everything the app needed:

- Next.js 15 App Router with TypeScript (the current way Next.js works)
- Tailwind for styling, nothing else
- Supabase for auth and the database
- RLS on every table: user_id = auth.uid(), no exceptions
- No service-role key in the browser
- Specific routes: /login, /signup, /app (feed), /app/boards, /app/boards/:id
- Masonry layout without a JS library if possible
- Email confirmation working end-to-end

## The build

Claude scaffolded the entire app in one session. I read each file as it was written and asked questions when I didn't understand a decision — why the server client uses await cookies() (Next.js 15 changed how cookies work in server components), why the masonry layout is CSS columns rather than a library (no JS needed, columns-based masonry is well-supported and simple).

## The email confirmation fix

The first version of the signup page redirected to /app after clicking the confirmation link, which only works if email confirmation is disabled. When confirmation is enabled, Supabase sends a ?code= parameter and expects the app to call auth.exchangeCodeForSession(code) before the session is active.

Adding the /auth/callback route fixed it. The signup page now sends the user to /auth/callback after clicking the email link; that route exchanges the code, then redirects to /app.

## What worked

The database schema being written as a migration file I could paste directly into the Supabase SQL editor was faster than using their GUI. Having RLS policies and indexes in the same file made it easy to review.

The CSS masonry worked well. No library to maintain.

## What to do next

- Add a drag-to-reorder for pins within a board
- Support direct image upload (currently URL-only)
- Mobile layout polish
