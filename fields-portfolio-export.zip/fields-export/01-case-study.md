# Fields — Case Study

## What it is

Fields is a personal image pinboard — my own lightweight alternative to Pinterest. I paste in an image URL, give it a title or note if I feel like it, and drop it into a board. The feed shows everything newest-first in a masonry grid. No algorithm, no ads, no one else's taste in the mix.

I use it to collect visual reference for projects, track design details I want to revisit, and keep screenshots of work I'm proud of.

## Why it was made

I'd been using Pinterest for reference but kept running into the same friction: suggested pins, an algorithm deciding what to surface, and an interface built for discovery rather than retrieval. I wanted something that was just mine — a grid of images I saved, organized the way I want, with no noise around them.

Building it myself also gave me a reason to work with Supabase's auth and row-level security on a real project.

## How it's built

The stack is Next.js 15 with the App Router, Tailwind CSS for styling, and Supabase for auth and the database. No external state library, no ORM — just the Supabase client talking directly to PostgreSQL.

Row Level Security on every table means the database itself enforces that each user sees only their own data. No service-role key is used anywhere in the app; the browser key can't access another user's rows no matter what.

The masonry layout is CSS columns — no JavaScript library, just `columns-2 sm:columns-3 lg:columns-4` with `break-inside-avoid` on each card.

## What the AI did

Claude built the whole thing in one session. I described what I wanted — a minimal pinboard, specific tech stack, RLS on every table, no framework magic — and Claude scaffolded the entire app: file structure, auth pages, database schema, middleware, components, migration SQL. I reviewed each part as it was written.

The only debugging I did myself was finding the right Supabase anon key (the dashboard shows it in two places; one is truncated). The email confirmation redirect required a small back-and-forth to understand the PKCE flow — Claude explained why a /auth/callback route was needed and wrote it.

## What I did

I wrote the full specification before anything was generated: the exact tech stack, the database shape, what RLS policies were required, what routes would exist, how the masonry layout should behave. The spec was detailed enough that Claude could build to it rather than guess.

During the build I reviewed each file as it was written, asked questions when something wasn't clear, and made the call on structure — where the auth guard should live, whether to use a JS library for masonry (decided no), how the board and pin data should be fetched.

## What I learned

The build went fast because the specification was precise. Every ambiguity I left out of the spec became a question Claude had to ask or a guess it had to make. The parts that required the most back-and-forth — the email confirmation redirect, the exact anon key location — were things I hadn't fully specified upfront.

RLS being at the database layer is genuinely reassuring. The security doesn't depend on the application code doing the right thing; a bug in the app can't accidentally expose someone else's data because the database won't return it.
