# Fields — Version History (to fill in)

Only FieldV3 is in the current repo. If V1 and V2 existed, fill in below and uncomment the versions module in `03-page-modules.js`.

## V1

- When was it built?
- What stack did it use?
- What did it look like?
- What didn't work or what was the main limitation?

## V2

- What changed from V1?
- Why wasn't it enough?
- What carried forward into V3?

## V3 (current)

- Started from scratch in a new repo (FieldV3)
- Next.js 15 + TypeScript + Tailwind + Supabase
- RLS on every table, no service-role key in the browser
- CSS-only masonry, email auth with PKCE flow
- Built in a single session with Claude
