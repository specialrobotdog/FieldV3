// Fields — data.js page modules
// Drop these into the project's sections array for the Fields page.
// Replace image placeholders with actual filenames after capturing screenshots.

const fields = {
  slug: "fields",
  title: "Fields",
  accent: "#4338ca", // Choose: #4338ca indigo, #d97706 amber, #475569 slate, #0f766e teal
  sections: [
    {
      type: "centered-dark",
      eyebrow: "01  -  Fields",
      heading: "A private pinboard I actually use.",
    },
    {
      type: "split",
      eyebrow: "01  -  What it is",
      heading: "Save anything. Organize it later.",
      body: "Fields is a personal image pinboard — my own lightweight alternative to Pinterest. I paste in an image URL, give it a title or note if I feel like it, and drop it into a board. The feed shows everything newest-first in a masonry grid. No algorithm, no ads, no one else's taste in the mix.\n\nI use it to collect visual reference for projects, track design details I want to revisit, and keep screenshots of work I'm proud of.",
      image: "fields-01-feed.png",
      imagePosition: "right",
    },
    {
      type: "split",
      eyebrow: "02  -  Why",
      heading: "Pinterest got in the way.",
      body: "I'd been using Pinterest for reference but kept running into the same friction: suggested pins, an algorithm deciding what to surface, and an interface built for discovery rather than retrieval. I wanted something that was just mine — a grid of images I saved, organized the way I want, with no noise around them.\n\nBuilding it myself also gave me a reason to work with Supabase's auth and row-level security on a real project.",
      image: "fields-02-boards.png",
      imagePosition: "left",
    },
    {
      type: "split",
      eyebrow: "03  -  How it's built",
      heading: "Next.js, Supabase, Tailwind. Nothing else.",
      body: "The stack is Next.js 15 with the App Router, Tailwind CSS for styling, and Supabase for auth and the database. No external state library, no ORM — just the Supabase client talking directly to PostgreSQL.\n\nRow Level Security on every table means the database itself enforces that each user sees only their own data. No service-role key is used anywhere in the app; the browser key can't access another user's rows no matter what.\n\nThe masonry layout is CSS columns — no JavaScript library, just columns-2 sm:columns-3 lg:columns-4 with break-inside-avoid on each card.",
      image: "fields-03-board-detail.png",
      imagePosition: "right",
    },
    {
      type: "centered-dark",
      eyebrow: "04  -  What the AI did",
      heading: "Claude built the whole thing in one session.",
      body: "I described what I wanted — a minimal pinboard, specific tech stack, RLS on every table, no framework magic — and Claude scaffolded the entire app: file structure, auth pages, database schema, middleware, components, migration SQL. I reviewed each part as it was written.\n\nThe only debugging I did myself was finding the right Supabase anon key (the dashboard shows it in two places; one is truncated). The email confirmation redirect required a small back-and-forth to understand the PKCE flow — Claude explained why a /auth/callback route was needed and wrote it.",
    },
    {
      type: "split",
      eyebrow: "04  -  What I did",
      heading: "Spec, review, and the decisions that matter.",
      body: "I wrote the full specification before anything was generated: the exact tech stack, the database shape, what RLS policies were required, what routes would exist, how the masonry layout should behave. The spec was detailed enough that Claude could build to it rather than guess.\n\nDuring the build I reviewed each file as it was written, asked questions when something wasn't clear, and made the call on structure — where the auth guard should live, whether to use a JS library for masonry (decided no), how the board and pin data should be fetched.",
      image: "fields-04-create-pin.png",
      imagePosition: "left",
    },
    {
      type: "gallery",
      eyebrow: "05  -  Screens",
      images: [
        "fields-screens-login.png",
        "fields-screens-signup.png",
        "fields-screens-feed.png",
        "fields-screens-boards.png",
        "fields-screens-board-detail.png",
        "fields-screens-create-pin.png",
      ],
    },
    {
      type: "split",
      eyebrow: "06  -  What I learned",
      heading: "The spec is the product.",
      body: "The build went fast because the specification was precise. Every ambiguity I left out of the spec became a question Claude had to ask or a guess it had to make. The parts that required the most back-and-forth — the email confirmation redirect, the exact anon key location — were things I hadn't fully specified upfront.\n\nRLS being at the database layer is genuinely reassuring. The security doesn't depend on the application code doing the right thing; a bug in the app can't accidentally expose someone else's data because the database won't return it.",
      image: "fields-05-feed-loaded.png",
      imagePosition: "right",
    },
    // Uncomment and fill in if you have V1/V2 history:
    // {
    //   type: "centered-dark",
    //   eyebrow: "07  -  Versions",
    //   heading: "[What changed between V1, V2 and V3]",
    //   body: "[Fill in: What did V1 look like? What didn't work? What did V2 try to fix? What made you start over with V3?]",
    // },
  ],
};
