# Fields — Screenshot Guide

Capture at **1440px wide**, **2x retina**. Use test data — no personal pins or real account info visible.

| # | Filename | What to capture |
|---|---|---|
| 1 | `fields-01-feed.png` | Masonry feed with 6–10 pins loaded, various aspect ratios |
| 2 | `fields-02-boards.png` | Boards list page with 2–3 boards |
| 3 | `fields-03-board-detail.png` | Single board view with its pins |
| 4 | `fields-04-create-pin.png` | Create pin modal open, fields visible |
| 5 | `fields-05-feed-loaded.png` | Feed with real content, alternate angle or scroll position |
| 6 | `fields-screens-login.png` | Login page, empty form |
| 7 | `fields-screens-signup.png` | Signup page, empty form |
| 8 | `fields-screens-feed.png` | Feed — same or similar to #1, for gallery |
| 9 | `fields-screens-boards.png` | Boards list — same or similar to #2, for gallery |
| 10 | `fields-screens-board-detail.png` | Board detail — same or similar to #3, for gallery |
| 11 | `fields-screens-create-pin.png` | Create pin — same or similar to #4, for gallery |
| 12 | `fields-mobile-feed.png` | Phone-width (375px), 2-column masonry feed |

## Tips

- Use Chrome DevTools device toolbar to set exact widths
- For retina: in DevTools, set device pixel ratio to 2, then use "Capture full size screenshot"
- Crop to content — no browser chrome in the final images
- Gallery images (#6–11) can be the same captures as #1–4 if framing works
- For placeholder pins, use Unsplash URLs pasted into the app
