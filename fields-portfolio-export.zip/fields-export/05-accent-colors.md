# Fields — Accent Color Options

Pick one. It floods the screen when a visitor clicks into the Fields page from the index.

| Swatch | Name | Hex | Notes |
|---|---|---|---|
| Indigo | `#4338ca` | Strong contrast on cream, distinct from red (R1 Dial) | Currently set as default in the modules file |
| Amber | `#d97706` | Warm, different energy from the other projects |
| Slate | `#475569` | Neutral and restrained, lets screenshots lead |
| Teal | `#0f766e` | Fresh, uncommon in portfolios |
